import React, { Component } from "react";
import R2d2 from '../img/R2-D2.jpg'
import "./random-planet.css";

class RandomPlanet extends Component {
  render() {
    return (
      <div className="random-planet jumbotron rounded">
        <img
          className="planet_image"
          src={R2d2}
          alt=""
        />
        <div>
            <h4>Planet Name</h4>
            <ul className="list-group list-group-flush">
                <li className="list-group-item">
                    <span className="term">Population</span>
                    <span>123124</span>
                </li>
                <li className="list-group-item">
                    <span className="term">Rotation Period</span>
                    <span>43</span>
                </li>
                <li className="list-group-item">
                    <span className="term">Diameter</span>
                    <span>100</span>
                </li>
                
            </ul>
        </div>
      </div>
    );
  }
}

export default RandomPlanet