import './spinner.css'

const Spinner = ()=>{
    return( <div className="loadingio-spinner-dual-ring-70fjypcwkza"><div className="ldio-a81nbxyehja">
<div></div><div><div></div></div>
</div></div>
    )
}
export default Spinner